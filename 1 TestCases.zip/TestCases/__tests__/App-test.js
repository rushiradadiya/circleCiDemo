// Copyright (c) 2014-present, Facebook, Inc. All rights reserved.

/**
 * Sample React Native Snapshot Test
 */

'use strict';

import 'react-native';
import React from 'react';
import App from '../App';

// Note: test renderer must be required after react-native.
import renderer from 'react-test-renderer';


it('renders correctly', () => {
  const tree = renderer.create(<App />).toJSON();
  expect(tree).toMatchSnapshot();
});

it('renders the ActivityIndicator component', () => {
  const ActivityIndicator = require('ActivityIndicator');
  const tree = renderer
      .create(<ActivityIndicator animating={true} size="small" />)
      .toJSON();
  expect(tree).toMatchSnapshot();
});
//
// it('renders the TextInput component', () => {
//   const TextInput = require('TextInput');
//   const tree = renderer
//       .create(<TextInput autoCorrect={false} rejectResponderTermination={true} value="apple banana kiwi" />)
//       .toJSON();
//   expect(tree).toMatchSnapshot();
// });

it('render change method', () => {
  const tree = renderer.create(<App />).getInstance();
  expect(tree.change(2)).toEqual(20);
});
